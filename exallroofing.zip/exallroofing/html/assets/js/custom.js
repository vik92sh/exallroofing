$(document).ready(function(){
    $(".mob-menu").click(function(){
    $(this).toggleClass("active");
    $(".navbar").slideToggle();
    });
});



// let mobMenu = document.querySelector('.mob-menu');
// let navBar = document.querySelector('.navbar');

// mobMenu.addEventListener('click',(e)=>{
//     e.currentTarget.previousElementSibling.classList.toggle("navshow")
//     e.currentTarget.classList.toggle("active")
// })
